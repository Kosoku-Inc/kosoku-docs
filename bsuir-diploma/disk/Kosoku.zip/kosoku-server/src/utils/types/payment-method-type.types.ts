export enum PaymentMethodType {
	Card = 'CARD',
	Cash = 'CASH',
}
