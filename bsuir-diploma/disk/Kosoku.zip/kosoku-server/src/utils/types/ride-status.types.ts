export enum RideStatus {
	Starting = 'STARTING',
	inProgress = 'IN_PROGRESS',
	Completed = 'COMPLETED',
	Declined = 'DECLINED',
}
