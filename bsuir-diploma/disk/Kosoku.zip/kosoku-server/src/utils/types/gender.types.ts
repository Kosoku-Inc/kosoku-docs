export enum Gender {
	Male = 'MALE',
	Female = 'FEMALE',
}
