export type StatusWrapper = {
	status: number;
};
