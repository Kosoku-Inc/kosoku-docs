export type AuthOutput = {
	token: string;
	refreshToken: string;
};
