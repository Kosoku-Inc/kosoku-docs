export type CreatePaymentIntentOutput = {
	clientSecret: string;
};
