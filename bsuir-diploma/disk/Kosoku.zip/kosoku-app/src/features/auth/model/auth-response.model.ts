import { Response } from '../../../core/model/response.model';
import { Tokens } from '../../../core/model/tokens.model';

export type AuthResponse = Response<Tokens>;
