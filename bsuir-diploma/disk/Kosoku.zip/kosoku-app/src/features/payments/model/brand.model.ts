export enum CardBrand {
    Visa = 'VISA',
    Mastercard = 'MASTERCARD',
    AmericanExpress = 'AMERICAN EXPRESS',
}
