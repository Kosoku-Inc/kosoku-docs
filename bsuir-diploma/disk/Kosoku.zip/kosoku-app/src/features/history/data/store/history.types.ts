import { Ride } from '../../../../core/model/ride.model';
import { State } from '../../../../core/model/state.model';

export type HistoryState = State<Array<Ride>>;
