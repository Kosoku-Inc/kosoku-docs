import { Ride } from '../../../core/model/ride.model';

export type Order = Ride;
