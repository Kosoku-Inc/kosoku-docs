import { Response } from '../../../core/model/response.model';
import { User } from '../../../core/model/user.model';

export type UserResponse = Response<User>;
