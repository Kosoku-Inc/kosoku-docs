export enum CarClass {
    Economy = 'Economy',
    Comfort = 'Comfort',
    Business = 'Business',
}
