export type Tokens = {
    token: string;
    refreshToken: string;
};
