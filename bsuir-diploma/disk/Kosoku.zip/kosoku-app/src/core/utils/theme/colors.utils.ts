export const colors = {
    white: '#fff',
    black: '#000',
    darkerGrey: '#040404',
    red: '#D61B0A',
    backgroundGrey: '#F6F6F7',
};
