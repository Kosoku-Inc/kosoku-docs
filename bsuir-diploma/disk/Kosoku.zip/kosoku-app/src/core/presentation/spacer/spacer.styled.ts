import styled from 'styled-components/native';

export const Spacer = styled.View`
    flex: 1;
`;

export const SpacerPressable = styled.Pressable`
    flex: 1;
`;
