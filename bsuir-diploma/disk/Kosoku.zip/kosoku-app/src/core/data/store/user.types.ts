import { State } from '../../model/state.model';
import { User } from '../../model/user.model';

export type UserState = State<User>;
