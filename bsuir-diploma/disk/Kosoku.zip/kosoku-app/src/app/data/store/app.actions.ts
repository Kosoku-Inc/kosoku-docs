import { createAction } from '@reduxjs/toolkit';

export const INITIALIZE = createAction('[Initialize]');
