module.exports = {
    project: {
        ios: {},
        android: {}, // grouped into "project"
    },
    assets: ['./assets/fonts/SFPro/', './assets/fonts/Ascent/'], // stays the same
};
